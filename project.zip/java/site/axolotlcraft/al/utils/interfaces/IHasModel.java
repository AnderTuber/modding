package site.axolotlcraft.al.utils.interfaces;

public interface IHasModel 
{
	public void registerModels();
}
